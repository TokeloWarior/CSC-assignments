# TOKELO MAKOLOANE
# 31-MAY-2021
# A program to find all palindromic primes between two integers N, M, supplied as input

import sys
sys.setrecursionlimit (30000)
rev = 0
def palindromicprime(N,M):

    number =str(N)
    if number == number[::-1]:
        b = check(N)
        if b == True:
            print(number) 
            if N!=M:
                N=N+1
                palindromicprime(N,M)
                  
        else:
            if N!=M:
                N=N+1
                palindromicprime(N,M)                       
            
    else:
        if N!=M:
            N=N+1
            palindromicprime(N,M)       
    return ' '

   

def check(n):
    if n==1:
        return False
    elif n==2:
        return True
    else:
        for i in range(2,n):
            if n%i==0:
                return False
        return True


if __name__=='__main__':
    
    N = eval(input('Enter the starting point N:\n'))
    M = eval(input('Enter the ending point M:\n'))
    b = check(N)
    print("The palindromic primes are:")
    print(palindromicprime(N,M))    